package routes

import (
    "encoding/json"
    "net/http"

    "github.com/gorilla/mux"
    "github.com/prashanthkunchanapalli/synexiops/inventory-service/db"
    "github.com/prashanthkunchanapalli/synexiops/inventory-service/model"
    "strconv"
    "fmt"
)

// GET /api/inventory/items
func GetAllInventory(w http.ResponseWriter, r *http.Request) {
    rows, err := db.DB.Query("SELECT id, name, sku, quantity FROM inventory")
    if err != nil {
        http.Error(w, "❌ DB error", http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var items []model.Inventory
    for rows.Next() {
        var item model.Inventory
        if err := rows.Scan(&item.ID, &item.Name, &item.SKU, &item.Quantity); err != nil {
            http.Error(w, "❌ Row scan error", http.StatusInternalServerError)
            return
        }
        items = append(items, item)
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(items)
}

// POST /api/inventory/items
func CreateInventory(w http.ResponseWriter, r *http.Request) {
    var item model.Inventory
    if err := json.NewDecoder(r.Body).Decode(&item); err != nil {
        http.Error(w, "❌ Invalid request payload", http.StatusBadRequest)
        return
    }

    query := `INSERT INTO inventory (name, sku, quantity) VALUES ($1, $2, $3) RETURNING id`
    err := db.DB.QueryRow(query, item.Name, item.SKU, item.Quantity).Scan(&item.ID)
    if err != nil {
        http.Error(w, "❌ Failed to insert item", http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(item)
}

// PUT /api/inventory/items/{id}
func UpdateInventory(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id, err := strconv.Atoi(vars["id"])
    if err != nil {
        http.Error(w, "❌ Invalid ID", http.StatusBadRequest)
        return
    }

    var item model.Inventory
    if err := json.NewDecoder(r.Body).Decode(&item); err != nil {
        http.Error(w, "❌ Invalid input", http.StatusBadRequest)
        return
    }

    query := `UPDATE inventory SET name=$1, sku=$2, quantity=$3 WHERE id=$4`
    _, err = db.DB.Exec(query, item.Name, item.SKU, item.Quantity, id)
    if err != nil {
        http.Error(w, fmt.Sprintf("❌ Failed to update item: %v", err), http.StatusInternalServerError)
        return
    }

    item.ID = id
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(item)
}

// DELETE /api/inventory/items/{id}
func DeleteInventory(w http.ResponseWriter, r *http.Request) {
    vars := mux.Vars(r)
    id, err := strconv.Atoi(vars["id"])
    if err != nil {
        http.Error(w, "❌ Invalid ID", http.StatusBadRequest)
        return
    }

    query := `DELETE FROM inventory WHERE id=$1`
    _, err = db.DB.Exec(query, id)
    if err != nil {
        http.Error(w, fmt.Sprintf("❌ Failed to delete item: %v", err), http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusNoContent)
}
