package db

type Config struct {
	Host     string
	Port     string
	User     string
	Password string
	DBName   string
}
