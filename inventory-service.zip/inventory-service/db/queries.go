package db

import (
	"synexiops/inventory-service/model"
)

// GetAllInventories returns all items
func GetAllInventories() ([]model.Inventory, error) {
	rows, err := DB.Query("SELECT id, name, sku, quantity FROM inventory")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var inventories []model.Inventory
	for rows.Next() {
		var inv model.Inventory
		if err := rows.Scan(&inv.ID, &inv.Name, &inv.SKU, &inv.Quantity); err != nil {
			return nil, err
		}
		inventories = append(inventories, inv)
	}
	return inventories, nil
}

func CreateInventory(inv model.Inventory) error {
	_, err := DB.Exec("INSERT INTO inventory (name, sku, quantity) VALUES ($1, $2, $3)",
		inv.Name, inv.SKU, inv.Quantity)
	return err
}

func UpdateInventory(inv model.Inventory) error {
	_, err := DB.Exec("UPDATE inventory SET name=$1, sku=$2, quantity=$3 WHERE id=$4",
		inv.Name, inv.SKU, inv.Quantity, inv.ID)
	return err
}

func DeleteInventory(id int) error {
	_, err := DB.Exec("DELETE FROM inventory WHERE id=$1", id)
	return err
}
