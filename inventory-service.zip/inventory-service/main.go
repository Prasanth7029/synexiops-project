package main

import (
	"fmt"
	"log"
	"net/http"

	"synexiops/inventory-service/db"
	"synexiops/inventory-service/routes"
)

func main() {
	dbConfig := db.Config{
		Host:     "localhost",
		Port:     "5432",
		User:     "postgres",
		Password: "@Srinani7029",
		DBName:   "inventorydb",
	}

	db.InitDB(dbConfig)
    router := routes.SetupRouter()
	fmt.Println("🚀 Inventory service running at http://localhost:8082")
	log.Fatal(http.ListenAndServe(":8082", router))
}
